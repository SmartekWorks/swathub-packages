' Get params from command line
Dim strPad, strBasePath, strIsHTMLBody, strAccount, strTo, strCC, strBCC, strSubject, strBody, strAttachments, arrAttachments
strPad = "ting.FileSys"
Set objFSO = CreateObject("Scrip" & strPad & "temObject")
Set objArgs = WScript.Arguments
strBasePath = objFSO.GetAbsolutePathName(objArgs(0))
strIsHTMLBody = objArgs(1)

On Error Resume Next

' Include common scripts
Dim strCWD, strCommon
strCWD = Left(WScript.ScriptFullName, InStrRev(WScript.ScriptFullName, "\") - 1)
Set objCommonFile = objFSO.OpenTextFile(objFSO.BuildPath(strCWD, "Common.vbs"))
strCommon = objCommonFile.ReadAll
ExecuteGlobal strCommon
objCommonFile.Close
Set objCommonFile = Nothing
If Err.Number <> 0 Then
    WScript.Echo "Import script error: " & Err.Description
    WScript.Quit
End If

' Get params from text file
strAccount = GetParamFromFile(strBasePath & "\account.txt")
strTo = GetParamFromFile(strBasePath & "\to.txt")
strCC = GetParamFromFile(strBasePath & "\cc.txt")
strBCC = GetParamFromFile(strBasePath & "\bcc.txt")
strSubject = GetParamFromFile(strBasePath & "\subject.txt")
strBody = GetParamFromFile(strBasePath & "\body.txt")
strAttachments = GetParamFromFile(strBasePath & "\attachments.txt")
If strAttachments <> "" Then
    arrAttachments = Split(strAttachments, vbCrLf)
End If

' Start sending mail
strPad = "ook.App"
Set objOutlook = CreateObject("Outl" & strPad & "lication")
Set objNamespace = objOutlook.GetNamespace("MAPI")

' Find the account by name. If no account is specified, Outlook uses the default account.
Set objSendAccount = Nothing
If strAccount <> "" Then
    For Each oAccount In objOutlook.Session.Accounts
        If oAccount = strAccount Then
            Set objSendAccount = oAccount
            Exit For
        End If
    Next
    If objSendAccount Is Nothing Then
        WScript.Echo "[ERROR] Account not exists!"
        WScript.Quit
    End If
End If

Set objMailItem = objOutlook.CreateItem(0)  ' olMailItem
With objMailItem
    If Not objSendAccount Is Nothing Then
        Set .SendUsingAccount = objSendAccount
    End If
    .To = strTo
    .CC = strCC
    .BCC = strBCC
    .Subject = strSubject
End With
If strIsHTMLBody = "true" Then
    objMailItem.BodyFormat = 2 ' olFormatHTML
    objMailItem.HTMLBody = strBody
Else
    objMailItem.Body = strBody
End If
If strAttachments <> "" Then
    For i = 0 To UBound(arrAttachments)
        objMailItem.Attachments.Add arrAttachments(i)
    Next
End If
objMailItem.Send

If Err.Number <> 0 Then
    Call WriteTextFile(strBasePath & "\error.txt", "Send mails error: " & Err.Description)
    WScript.Quit
End If

' Release system resources
Set objArgs = Nothing
Set objFSO = Nothing
Set objOutlook = Nothing
Set objNamespace = Nothing

' Return success signal
WScript.Echo "OK"

On Error Goto 0
