' Get param from file
Function GetParamFromFile(strPath)
    If objFSO.FileExists(strPath) Then
        Set objReadStream = CreateObject("ADODB.Stream")
        With objReadStream
            .CharSet = "UTF-8"
            .Open
            .LoadFromFile(strPath)
            GetParamFromFile = objReadStream.ReadText()
            .Close
        End With
        Set objReadStream = Nothing
    Else
        GetParamFromFile = ""
    End If
End Function

' Write text into file
Sub WriteTextFile(strPath, strContent)
    Set objWriteStream = CreateObject("ADODB.Stream")   ' UTF-8 BOM
    Set objWriteStream2 = CreateObject("ADODB.Stream")  ' Convert to UTF-8
    With objWriteStream
        .Type = 2   ' text
        .CharSet = "UTF-8"
        .Open
        .WriteText strContent
        .Position = 3   ' skip first char
    End With
    With objWriteStream2
        .Type = 1   ' binary
        .Open
        objWriteStream.CopyTo objWriteStream2
        .SaveToFile strPath, 2   ' overwrite
    End With
    objWriteStream.Close
    objWriteStream2.Close
End Sub

' Get folder by path
Function GetFolderByPath(objParentFolder, strPath)
    ' WScript.Echo "Folder: " & objParentFolder & " Full Path: " & strPath
    Set objChildFolder = Nothing
    arrFolderNames = Split(strPath, "/")
    If UBound(arrFolderNames) = 0 Then
        arrFolderNames = Split(strPath, "\")
    End If    
    strFolderName = arrFolderNames(0)
    ' WScript.Echo "Folder Name: " & strFolderName
    For Each objFolder In objParentFolder.Folders
        If objFolder.Name = strFolderName Then
            Set objChildFolder = objFolder
        End If
    Next
    If objChildFolder Is Nothing Then
        WScript.Echo "[ERROR] Folder not exists!"
        WScript.Quit
    Else
        Set objInboxFolder = objChildFolder
    End If
    If UBound(arrFolderNames) = 0 Then
        GetFolderByPath = objChildFolder
    Else
        Dim strChildPath
        strChildPath = Mid(strPath, Len(strFolderName) + 2)
        GetFolderByPath objChildFolder, strChildPath
    End If
End Function