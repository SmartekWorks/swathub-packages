' Get params from command line
Dim strPad, strBasePath, strAccount, strFolder, strFilter, strMarkRead, strUnreadOnly, intTop
strPad = "ting.FileSys"
Set objFSO = CreateObject("Scrip" & strPad & "temObject")
Set objArgs = WScript.Arguments
strBasePath = objFSO.GetAbsolutePathName(objArgs(0))
strMarkRead = objArgs(1)
strUnreadOnly = objArgs(2)
intTop = CInt(objArgs(3))

On Error Resume Next

' Include common scripts
Dim strCWD, strCommon
strCWD = Left(WScript.ScriptFullName, InStrRev(WScript.ScriptFullName, "\") - 1)
Set objCommonFile = objFSO.OpenTextFile(objFSO.BuildPath(strCWD, "Common.vbs"))
strCommon = objCommonFile.ReadAll
ExecuteGlobal strCommon
objCommonFile.Close
Set objCommonFile = Nothing
If Err.Number <> 0 Then
    WScript.Echo "Import script error: " & Err.Description
    WScript.Quit
End If

' Get params from text file
strAccount = GetParamFromFile(strBasePath & "\account.txt")
strFolder = GetParamFromFile(strBasePath & "\folder.txt")
strFilter = GetParamFromFile(strBasePath & "\filter.txt")

' Start fetching mails
strPad = "ook.App"
Set objOutlook = CreateObject("Outl" & strPad & "lication")
Set objNamespace = objOutlook.GetNamespace("MAPI")

' Find the account by name
Set objRootFolder = Nothing
For Each oAccount In objOutlook.Session.Accounts
    IF objRootFolder is Nothing And strAccount = "" Then
        Set objRootFolder = oAccount.DeliveryStore.GetRootFolder
    End If
    If oAccount = strAccount And strAccount <> "" Then
        Set objRootFolder = oAccount.DeliveryStore.GetRootFolder
    End If
Next
If objRootFolder Is Nothing Then
    WScript.Echo "[ERROR] Account not exists!"
    WScript.Quit
End If

' Find the folder by path
Set objInboxFolder = Nothing
If strFolder = "" Then
    Set objInboxFolder = objNamespace.GetDefaultFolder(6)   ' olFolderInbox = 6
Else
    GetFolderByPath objRootFolder, strFolder
End If

' WScript.Echo "Inbox Folder: " & objInboxFolder

' Get mail items
Set objMailItems = objInboxFolder.Items
If strUnreadOnly = "true" Then
    Set objMailItems = objMailItems.Restrict("[Unread]=true")
End If
If strFilter <> "" Then
    Set objMailItems = objMailItems.Restrict(strFilter)
End If
objMailItems.Sort "[ReceivedTime]", False    ' ascending
' WScript.Echo "Mail items count: " & objMailItems.Count

Dim intCounter, i, j, strSenderAddress
intCounter = 1
For i = objMailItems.Count To 1 Step -1
    Set objMailItem = objMailItems(i)
    ' WScript.Echo "Mail(" & i & "): " & objMailItem.Subject & "Type: " & TypeName(objMailItem)
    If TypeName(objMailItem) = "MailItem" Then
        ' Create folder for each mail item
        strMsgFolder = strBasePath & "\" & Right("000" & CStr(intCounter), 3)
        If Not objFSO.FolderExists(strMsgFolder) Then
            objFSO.CreateFolder strMsgFolder
        End If

        ' Save mail data to text file in utf-8
        ' If objMailItem.BodyFormat = 1 Then  ' olFormatPlain = 1
        '     strMailBody = objMailItem.Body
        ' Else
        '     strMailBody = objMailItem.HTMLBody
        ' End If

        If objMailItem.SenderEmailType = "EX" Then  ' EX for internal mails
            strSenderAddress = objMailItem.Sender.GetExchangeUser().PrimarySmtpAddress
        Else ' SMTP for external mails
            strSenderAddress = objMailItem.SenderEmailAddress
        End If

        Set objWriteStream = CreateObject("ADODB.Stream")   ' UTF-8 BOM
        Set objWriteStream2 = CreateObject("ADODB.Stream")  ' Convert to UTF-8
        With objWriteStream
            .Type = 2   ' text
            .CharSet = "UTF-8"
            .Open
            .WriteText "#receivedTime#" & objMailItem.ReceivedTime & "#!receivedTime#" & vbNewLine
            .WriteText "#from#" & strSenderAddress & "#!from#" & vbNewLine
            .WriteText "#to#" & objMailItem.To & "#!to#" & vbNewLine
            .WriteText "#cc#" & objMailItem.CC & "#!cc#" & vbNewLine
            .WriteText "#bcc#" & objMailItem.BCC & "#!bcc#" & vbNewLine
            .WriteText "#subject#" & objMailItem.Subject & "#!subject#" & vbNewLine
            .WriteText "#body#" & objMailItem.Body & "#!body#"
            .Position = 3   ' skip first char
        End With
        With objWriteStream2
            .Type = 1   ' binary
            .Open
            objWriteStream.CopyTo objWriteStream2
            .SaveToFile strMsgFolder & "\mail.txt", 2   ' overwrite
        End With
        objWriteStream.Close
        objWriteStream2.Close

        ' Save attachments if exists
        intAttachCount = objMailItem.Attachments.Count
        ' WScript.Echo "Mail: " & objMailItem.Subject & " Attachment size: " & intAttachCount
        If intAttachCount > 0 Then
            For j = 1 To intAttachCount Step 1
                objMailItem.Attachments.Item(j).SaveAsFile strMsgFolder & "\" & objMailItem.Attachments.Item(j).FileName
            Next
        End If        

        ' Mark as read if necessary
        If strMarkRead = "true" Then
            objMailItem.UnRead = False
            objMailItem.Save
        End If

        ' Check if exceeds maximum mail items
        intCounter = intCounter + 1
        If intCounter > intTop Then
            Exit For
        End If
    End If
Next

If Err.Number <> 0 Then
    Call WriteTextFile(strBasePath & "\error.txt", "Get mails error: " & Err.Description)
    WScript.Quit
End If

' Release system resources
Set objArgs = Nothing
Set objFSO = Nothing
Set objOutlook = Nothing
Set objNamespace = Nothing

' Return success signal
WScript.Echo "OK"

On Error Goto 0
