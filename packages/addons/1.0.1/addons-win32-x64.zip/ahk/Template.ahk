; common start
#Include Clip.ahk
#Include JavaAccessBridge.ahk

SetTitleMatchMode, Regex
if not WinExist("@{winTitle}") {
  FileAppend, Application not found!`n, @{workDir}\error.txt, UTF-8
  return
}
WinActivate, @{winTitle}

endTime := A_TickCount + @{timeout} * 1000
currentTime := A_TickCount
javaObj := -1
name := ""
role := ""
while (currentTime < endTime) {
  @{selectors}
}
if not IsObject(javaObj) {
  FileAppend, Java %role% (%name%) not found!`n, @{workDir}\error.txt, UTF-8
  return
}
; common end

; selector start
  FileRead, name@{seq}, @{workDir}\name@{seq}.txt
  name := name@{seq}
  role := "@{role}"
  javaObj := JavaControlGet(0, name@{seq}, role, "", "@{index}", @{parent})
  if IsObject(javaObj) {
    @{break}
  } else {
    FileAppend, %currentTime% - Java %role% (%name%) not found!`n, @{workDir}\log.txt, UTF-8
    sleep, 1000
    currentTime := A_TickCount
    continue
  }
; selector end

; click start
rval := JavaControlDoActionSimple(javaObj, "@{action}")
if (rval < 0) {
  FileAppend, Java action (%action%) failed! (%rval%)`n, @{workDir}\error.txt, UTF-8
  return
}
; click end

; type start
rval := JavaControlDoActionSimple(javaObj, "focus")
if (rval < 0) {
  FileAppend, Java action (focus) failed! (%rval%)`n, @{workDir}\error.txt, UTF-8
  return
}
SendInput, ^a
sleep, 100
SendInput, {BS}
sleep, 100
; type end

; key start
SendInput, @{key}
sleep, 100
; key end

; text start
Clip("@{text}")
sleep, 100
; text end

; getText start
rval := JavaControlDoActionSimple(javaObj, "focus")
if (rval < 0) {
  FileAppend, Java action (focus) failed! (%rval%)`n, @{workDir}\error.txt, UTF-8
  return
}
rval := GetTextInfo()
FileAppend, %rval%, @{workDir}\output.txt, UTF-8
; getText end

; focus start
rval := JavaControlDoActionSimple(javaObj, "focus")
if (rval < 0) {
  FileAppend, Java action (focus) failed! (%rval%)`n, @{workDir}\error.txt, UTF-8
  return
}
; focus end

; elementExists start
FileAppend, true, @{workDir}\output.txt, UTF-8
; elementExists end
