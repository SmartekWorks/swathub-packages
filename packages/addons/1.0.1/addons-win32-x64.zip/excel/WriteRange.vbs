' Get params from command line
On Error Resume Next
Dim strPad, strBasePath, strFile, strSheet, strCell, strPassword
Dim savedDisplayAlerts, savedAlertBeforeOverwriting, applicationStateCaptured
Dim savedEnableEvents, eventsStateCaptured, activationChanged
Dim previousActiveWorkbook, previousActiveSheet
Const RETRY_COUNT = 4
Const RETRY_DELAY_MS = 1000
strPad = "ting.FileSys"
Set objFSO = CreateObject("Scrip" & strPad & "temObject")
Set objArgs = WScript.Arguments
If objArgs.Count < 4 Then
    WScript.Echo "Write range error (Arguments): Expected work path, workbook, sheet and cell"
    WScript.Quit 0
End If
strBasePath = objFSO.GetAbsolutePathName(objArgs(0))
strFile = objArgs(1)
strSheet = objArgs(2)
strCell = objArgs(3)
strPassword = ""
If objArgs.Count > 4 Then strPassword = objArgs(4)

' Include common scripts
Dim strCWD, strCommon
strCWD = Left(WScript.ScriptFullName, InStrRev(WScript.ScriptFullName, "\") - 1)
Set objCommonFile = objFSO.OpenTextFile(objFSO.BuildPath(strCWD, "Common.vbs"))
strCommon = objCommonFile.ReadAll
ExecuteGlobal strCommon
objCommonFile.Close
Set objCommonFile = Nothing
If Err.Number <> 0 Then
    WScript.Echo "Import script error: " & Err.Description
    WScript.Quit
End If

' Open workbook
Dim isExcelActive, isWorkbookActive
isExcelActive = False
isWorkbookActive = False
Set objExcel = Nothing
Set objWorkbook = Nothing
Set objCSV = Nothing
Set previousActiveWorkbook = Nothing
Set previousActiveSheet = Nothing
applicationStateCaptured = False
eventsStateCaptured = False
activationChanged = False
Dim openError
openError = OpenTargetWorkbookWithRetry()
If openError <> "" Then Call FinishWriteRange(openError)

' A read-only network workbook must not be treated as a successful write.
Err.Clear
isReadOnly = objWorkbook.ReadOnly
If Err.Number <> 0 Then Call FailWriteRange("Check workbook", Err.Number, Err.Description)
If isReadOnly Then Call FinishWriteRange("Write range error: Workbook is read-only: " & strFile)

Dim prevEnableEvents, prevDisplayAlerts
prevEnableEvents = objExcel.EnableEvents
prevDisplayAlerts = objExcel.DisplayAlerts
objExcel.EnableEvents = False
objExcel.DisplayAlerts = False

' Open worksheet
Set objSheet = Nothing
Err.Clear
Call OpenWorksheet(objWorkbook, objSheet, strSheet)
If Err.Number <> 0 Then
    Call FinishWriteRange("Sheet not found: " & Err.Description)
End If

' Write from csv to range
Dim strRange, objSource, objTarget, rangeValues, rowIndex, colIndex
Dim savedNumberFormat, savedWrapText, restorePending
Dim cellNumberFormats(), cellWrapText()
Dim prefixCells, cellAddress, cellXML, dataTagStart, dataTagEnd, formatError
restorePending = False
Err.Clear
openError = OpenCsvWithRetry(strBasePath & "\data.csv")
If openError <> "" Then Call FinishWriteRange(openError)

Err.Clear
If objFSO.FileExists(strBasePath & "\range.txt") Then
    strRange = GetParamFromFile(strBasePath & "\range.txt")
Else
    strRange = "A1:" & objCSV.Sheets("data").Range("A1").SpecialCells(11).Address ' xlCellTypeLastCell
End If
If Err.Number <> 0 Then Call FailWriteRange("Read range address", Err.Number, Err.Description)

Err.Clear
Set objSource = objCSV.Sheets("data").Range(strRange)
If Err.Number <> 0 Then Call FailWriteRange("Get source range", Err.Number, Err.Description)
Set objTarget = objSheet.Range(strCell).Resize(objSource.Rows.Count, objSource.Columns.Count)
If Err.Number <> 0 Then Call FailWriteRange("Get target range", Err.Number, Err.Description)

' Keep Excel's existing CSV parsing and formula results, without using the
' clipboard. Value2 avoids the Currency/Date coercion performed by Value.
rangeValues = objSource.Value2
If Err.Number <> 0 Then Call FailWriteRange("Read source values", Err.Number, Err.Description)

' Snapshot formats before temporarily using text format to stop Excel from
' interpreting strings as numbers or formulas. Mixed ranges need per-cell
' snapshots; a single NumberFormat/WrapText would otherwise return Null.
savedNumberFormat = objTarget.NumberFormat
savedWrapText = objTarget.WrapText
If Err.Number <> 0 Then Call FailWriteRange("Read target formatting", Err.Number, Err.Description)
If IsNull(savedNumberFormat) Or IsNull(savedWrapText) Then
    ReDim cellNumberFormats(objTarget.Rows.Count, objTarget.Columns.Count)
    ReDim cellWrapText(objTarget.Rows.Count, objTarget.Columns.Count)
    For rowIndex = 1 To objTarget.Rows.Count
        For colIndex = 1 To objTarget.Columns.Count
            If IsNull(savedNumberFormat) Then cellNumberFormats(rowIndex, colIndex) = objTarget.Cells(rowIndex, colIndex).NumberFormat
            If IsNull(savedWrapText) Then cellWrapText(rowIndex, colIndex) = objTarget.Cells(rowIndex, colIndex).WrapText
        Next
    Next
End If
If Err.Number <> 0 Then Call FailWriteRange("Read target formatting", Err.Number, Err.Description)

' Text format alone preserves ordinary strings without adding quotePrefix.
' Only literal leading apostrophes still need escaping. Remember which of
' those cells did not already have a prefix, so it can be removed afterwards.
Set prefixCells = CreateObject("Scripting.Dictionary")
If IsArray(rangeValues) Then
    For rowIndex = LBound(rangeValues, 1) To UBound(rangeValues, 1)
        For colIndex = LBound(rangeValues, 2) To UBound(rangeValues, 2)
            If VarType(rangeValues(rowIndex, colIndex)) = vbString Then
                If Left(rangeValues(rowIndex, colIndex), 1) = "'" Then
                    If objTarget.Cells(rowIndex, colIndex).PrefixCharacter = "" Then prefixCells.Add objTarget.Cells(rowIndex, colIndex).Address, True
                    rangeValues(rowIndex, colIndex) = "'" & rangeValues(rowIndex, colIndex)
                End If
            End If
        Next
    Next
ElseIf VarType(rangeValues) = vbString Then
    If Left(rangeValues, 1) = "'" Then
        If objTarget.PrefixCharacter = "" Then prefixCells.Add objTarget.Address, True
        rangeValues = "'" & rangeValues
    End If
End If
If Err.Number <> 0 Then Call FailWriteRange("Prepare values", Err.Number, Err.Description)

restorePending = True
Dim retryErrorNumber, retryErrorDescription
If Not SetRangeNumberFormatWithRetry(objTarget, "@", retryErrorNumber, retryErrorDescription) Then Call FailWriteRange("Set temporary text format", retryErrorNumber, retryErrorDescription)
If Not SetRangeValuesWithRetry(objTarget, rangeValues, retryErrorNumber, retryErrorDescription) Then Call FailWriteRange("Write values", retryErrorNumber, retryErrorDescription)

' PrefixCharacter is read-only. Excel's native XML range value can remove
' its input marker while retaining the literal apostrophe and cell styles.
' Use Excel's XML unchanged except for the marker: parsing/reserializing it
' would normalize carriage returns and can reject Excel control characters.
If prefixCells.Count > 0 Then
    Err.Clear
    savedEnableEvents = objExcel.EnableEvents
    If Err.Number = 0 Then
        eventsStateCaptured = True
        objExcel.EnableEvents = False
    End If
    Err.Clear
    objWorkbook.Activate
    objSheet.Activate
    activationChanged = True
    If Err.Number <> 0 Then Call FailWriteRange("Activate text target", Err.Number, Err.Description)
End If
For Each cellAddress In prefixCells.Keys
    cellXML = objSheet.Range(cellAddress).Value(11) ' xlRangeValueXMLSpreadsheet
    If Err.Number <> 0 Then Call FailWriteRange("Read text prefix", Err.Number, Err.Description)
    dataTagStart = InStr(cellXML, "<Data ")
    If dataTagStart = 0 Then Call FinishWriteRange("Write range error (Restore text prefix): Missing XML data element")
    dataTagEnd = InStr(dataTagStart, cellXML, ">")
    If dataTagEnd = 0 Then Call FinishWriteRange("Write range error (Restore text prefix): Invalid XML data element")
    ' Limit the replacement to the opening tag, never the user's string.
    cellXML = Left(cellXML, dataTagStart - 1) & Replace(Mid(cellXML, dataTagStart, dataTagEnd - dataTagStart + 1), " x:Ticked=""1""", "") & Mid(cellXML, dataTagEnd + 1)
    objSheet.Range(cellAddress).Value(11) = cellXML
    If Err.Number <> 0 Then Call FailWriteRange("Restore text prefix", Err.Number, Err.Description)
Next
Call RestoreExcelInteractionState()

' Assigning a string with LF can enable WrapText. Restore the original
' wrapping and number formats, and let Excel manage automatic row heights.
formatError = RestoreTargetFormatting()
If formatError <> "" Then Call FinishWriteRange(formatError)

' Save only after the complete range was written successfully. Network shares
' and busy Excel instances can reject a single COM call transiently.
If Not SaveWorkbookWithRetry(retryErrorNumber, retryErrorDescription) Then Call FailWriteRange("Save workbook", retryErrorNumber, retryErrorDescription)
Call FinishWriteRange("")

On Error Goto 0

Function OpenTargetWorkbookWithRetry()
    On Error Resume Next
    Dim attempt, objFile, openedBook, candidate, targetPath, candidatePath
    Dim targetName, basenameConflict
    Dim lastNumber, lastDescription
    OpenTargetWorkbookWithRetry = ""
    targetPath = objFSO.GetAbsolutePathName(strFile)
    targetName = objFSO.GetFileName(strFile)
    basenameConflict = False

    ' Resolve the UNC/local file first. A brief SMB reconnect can fail once
    ' even though the same file opens normally when tried again by hand.
    For attempt = 1 To RETRY_COUNT
        Err.Clear
        Set objFile = objFSO.GetFile(strFile)
        If Err.Number = 0 Then Exit For
        lastNumber = Err.Number
        lastDescription = Err.Description
        Set objFile = Nothing
        If attempt < RETRY_COUNT Then WScript.Sleep RETRY_DELAY_MS * attempt
    Next
    If objFile Is Nothing Then
        OpenTargetWorkbookWithRetry = "Write range error (Access workbook, " & lastNumber & "): " & lastDescription & " [" & strFile & "]"
        Exit Function
    End If
    Set objFile = Nothing

    Err.Clear
    Set objExcel = GetObject(, "Excel.Application")
    If Err.Number <> 0 Then
        Err.Clear
        Set objExcel = CreateObject("Excel.Application")
        If Err.Number <> 0 Or objExcel Is Nothing Then
            OpenTargetWorkbookWithRetry = "Write range error (Open Excel, " & Err.Number & "): " & Err.Description
            Exit Function
        End If
        objExcel.Visible = False
        objExcel.ScreenUpdating = False
    Else
        isExcelActive = True
    End If

    Err.Clear
    savedDisplayAlerts = objExcel.DisplayAlerts
    savedAlertBeforeOverwriting = objExcel.AlertBeforeOverwriting
    If Err.Number = 0 Then applicationStateCaptured = True
    If isExcelActive Then
        Err.Clear
        Set previousActiveWorkbook = objExcel.ActiveWorkbook
        Set previousActiveSheet = objExcel.ActiveSheet
        Err.Clear
    End If
    objExcel.DisplayAlerts = False
    objExcel.AlertBeforeOverwriting = False
    If Err.Number <> 0 Then
        OpenTargetWorkbookWithRetry = "Write range error (Configure Excel, " & Err.Number & "): " & Err.Description
        Exit Function
    End If

    ' Match an already-open workbook by its full path. Comparing only the
    ' basename can select another history folder's input.xlsx.
    For Each candidate In objExcel.Workbooks
        Err.Clear
        candidatePath = objFSO.GetAbsolutePathName(candidate.FullName)
        If Err.Number = 0 Then
            If StrComp(candidatePath, targetPath, vbTextCompare) = 0 Then
                isWorkbookActive = True
                Set objWorkbook = candidate
                Exit For
            ElseIf StrComp(candidate.Name, targetName, vbTextCompare) = 0 Then
                basenameConflict = True
            End If
        End If
        Err.Clear
    Next
    If Not objWorkbook Is Nothing Then Exit Function

    ' Excel cannot keep two workbooks with the same basename open in one
    ' instance. History folders commonly contain many files named input.xlsx,
    ' so use an isolated instance instead of reusing or modifying the wrong one.
    If basenameConflict Then
        If applicationStateCaptured Then
            objExcel.DisplayAlerts = savedDisplayAlerts
            objExcel.AlertBeforeOverwriting = savedAlertBeforeOverwriting
        End If
        Set previousActiveWorkbook = Nothing
        Set previousActiveSheet = Nothing
        Set objExcel = Nothing
        isExcelActive = False
        applicationStateCaptured = False
        Err.Clear
        Set objExcel = CreateObject("Excel.Application")
        If Err.Number <> 0 Or objExcel Is Nothing Then
            OpenTargetWorkbookWithRetry = "Write range error (Open isolated Excel, " & Err.Number & "): " & Err.Description
            Exit Function
        End If
        objExcel.Visible = False
        objExcel.ScreenUpdating = False
        Err.Clear
        savedDisplayAlerts = objExcel.DisplayAlerts
        savedAlertBeforeOverwriting = objExcel.AlertBeforeOverwriting
        If Err.Number = 0 Then applicationStateCaptured = True
        objExcel.DisplayAlerts = False
        objExcel.AlertBeforeOverwriting = False
        If Err.Number <> 0 Then
            OpenTargetWorkbookWithRetry = "Write range error (Configure isolated Excel, " & Err.Number & "): " & Err.Description
            Exit Function
        End If
    End If

    For attempt = 1 To RETRY_COUNT
        Err.Clear
        Set openedBook = Nothing
        Set openedBook = objExcel.Workbooks.Open(strFile, , False, , strPassword)
        lastNumber = Err.Number
        lastDescription = Err.Description
        If Err.Number = 0 And openedBook Is Nothing Then
            lastNumber = 1004
            lastDescription = "Excel did not return the opened workbook"
        End If
        If Err.Number = 0 And Not openedBook Is Nothing Then
            Err.Clear
            If Not openedBook.ReadOnly Then
                Set objWorkbook = openedBook
                Exit Function
            End If
            lastNumber = 70
            lastDescription = "Workbook opened read-only"
            openedBook.Close False
            Set openedBook = Nothing
        End If
        If attempt < RETRY_COUNT Then WScript.Sleep RETRY_DELAY_MS * attempt
    Next
    OpenTargetWorkbookWithRetry = "Write range error (Open workbook, " & lastNumber & "): " & lastDescription & " [" & strFile & "]"
End Function

Function OpenCsvWithRetry(csvPath)
    On Error Resume Next
    Dim attempt, lastNumber, lastDescription
    OpenCsvWithRetry = ""
    For attempt = 1 To RETRY_COUNT
        Err.Clear
        Set objCSV = Nothing
        Set objCSV = objExcel.Workbooks.Open(csvPath, 0, True)
        lastNumber = Err.Number
        lastDescription = Err.Description
        If Err.Number = 0 And Not objCSV Is Nothing Then Exit Function
        If attempt < RETRY_COUNT Then WScript.Sleep RETRY_DELAY_MS * attempt
    Next
    OpenCsvWithRetry = "Write range error (Open CSV, " & lastNumber & "): " & lastDescription
End Function

Function SetRangeNumberFormatWithRetry(targetRange, numberFormat, ByRef lastNumber, ByRef lastDescription)
    On Error Resume Next
    Dim attempt
    SetRangeNumberFormatWithRetry = False
    For attempt = 1 To RETRY_COUNT
        Err.Clear
        targetRange.NumberFormat = numberFormat
        lastNumber = Err.Number
        lastDescription = Err.Description
        If Err.Number = 0 Then
            SetRangeNumberFormatWithRetry = True
            Exit Function
        End If
        If attempt < RETRY_COUNT Then WScript.Sleep RETRY_DELAY_MS * attempt
    Next
End Function

Function SetRangeValuesWithRetry(targetRange, values, ByRef lastNumber, ByRef lastDescription)
    On Error Resume Next
    Dim attempt
    SetRangeValuesWithRetry = False
    For attempt = 1 To RETRY_COUNT
        Err.Clear
        targetRange.Value2 = values
        lastNumber = Err.Number
        lastDescription = Err.Description
        If Err.Number = 0 Then
            SetRangeValuesWithRetry = True
            Exit Function
        End If
        If attempt < RETRY_COUNT Then WScript.Sleep RETRY_DELAY_MS * attempt
    Next
End Function

Function SaveWorkbookWithRetry(ByRef lastNumber, ByRef lastDescription)
    On Error Resume Next
    Dim attempt
    SaveWorkbookWithRetry = False
    For attempt = 1 To RETRY_COUNT
        Err.Clear
        objWorkbook.Save
        lastNumber = Err.Number
        lastDescription = Err.Description
        If Err.Number = 0 Then
            SaveWorkbookWithRetry = True
            Exit Function
        End If
        If attempt < RETRY_COUNT Then WScript.Sleep RETRY_DELAY_MS * attempt
    Next
End Function

Sub RestoreExcelInteractionState()
    On Error Resume Next
    If activationChanged And isExcelActive Then
        If Not previousActiveWorkbook Is Nothing Then previousActiveWorkbook.Activate
        If Not previousActiveSheet Is Nothing Then previousActiveSheet.Activate
    End If
    activationChanged = False
    If eventsStateCaptured Then objExcel.EnableEvents = savedEnableEvents
    eventsStateCaptured = False
    Err.Clear
End Sub

Sub FailWriteRange(strStage, errorNumber, errorDescription)
    Call FinishWriteRange("Write range error (" & strStage & ", " & errorNumber & "): " & errorDescription)
End Sub

Function RestoreTargetFormatting()
    On Error Resume Next
    RestoreTargetFormatting = ""
    If Not restorePending Then Exit Function
    restorePending = False
    Dim r, c
    Err.Clear
    If IsNull(savedNumberFormat) Then
        For r = 1 To objTarget.Rows.Count
            For c = 1 To objTarget.Columns.Count
                objTarget.Cells(r, c).NumberFormat = cellNumberFormats(r, c)
            Next
        Next
    Else
        objTarget.NumberFormat = savedNumberFormat
    End If
    If Err.Number <> 0 Then RestoreTargetFormatting = "Write range error (Restore number format): " & Err.Description
    Err.Clear
    If IsNull(savedWrapText) Then
        For r = 1 To objTarget.Rows.Count
            For c = 1 To objTarget.Columns.Count
                objTarget.Cells(r, c).WrapText = cellWrapText(r, c)
            Next
        Next
    Else
        objTarget.WrapText = savedWrapText
    End If
    If Err.Number <> 0 And RestoreTargetFormatting = "" Then RestoreTargetFormatting = "Write range error (Restore wrapping): " & Err.Description
End Function

Sub FinishWriteRange(strFailure)
    On Error Resume Next

    ' Also restore temporary formatting on failure in an already-open book.
    Dim cleanupFormatError
    cleanupFormatError = RestoreTargetFormatting()
    If strFailure = "" Then strFailure = cleanupFormatError
    Call RestoreExcelInteractionState()

    ' Never implicitly save partial writes during cleanup. Leave workbooks
    ' that were already open in the user's Excel instance open as before.
    Err.Clear
    If Not objCSV Is Nothing Then objCSV.Close False
    If Err.Number <> 0 And strFailure = "" Then strFailure = "Close CSV error: " & Err.Description
    Set objSource = Nothing
    Set objTarget = Nothing
    Set objCSV = Nothing
    Set objSheet = Nothing

    Err.Clear
    If Not objWorkbook Is Nothing Then
        If isWorkbookActive = False Then objWorkbook.Close False
    End If
    If Err.Number <> 0 And strFailure = "" Then strFailure = "Close workbook error: " & Err.Description
    Set objWorkbook = Nothing

    Err.Clear
    If Not objExcel Is Nothing Then
        If applicationStateCaptured Then
            objExcel.DisplayAlerts = savedDisplayAlerts
            objExcel.AlertBeforeOverwriting = savedAlertBeforeOverwriting
        Else
            objExcel.DisplayAlerts = True
            objExcel.AlertBeforeOverwriting = True
        End If
        If isExcelActive = False Then objExcel.Quit
    End If
    If Err.Number <> 0 And strFailure = "" Then strFailure = "Close excel error: " & Err.Description
    Set objExcel = Nothing

    ' Keep the original operation error even if cleanup also fails.
    If strFailure <> "" Then
        Call WriteTextFile(strBasePath & "\error.txt", strFailure)
        WScript.Echo strFailure
    Else
        WScript.Echo "OK"
    End If
    WScript.Quit 0
End Sub
