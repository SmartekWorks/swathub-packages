' Get params from command line
Dim strPad, strBasePath, strFile, strMacro, strPassword
strPad = "ting.FileSys"
Set objFSO = CreateObject("Scrip" & strPad & "temObject")
Set objArgs = WScript.Arguments
strBasePath = objFSO.GetAbsolutePathName(objArgs(0))
strFile = objArgs(1)
strMacro = objArgs(2)
strPassword = objArgs(3)

On Error Resume Next

' Include common scripts
Dim strCWD, strCommon
strCWD = Left(WScript.ScriptFullName, InStrRev(WScript.ScriptFullName, "\") - 1)
Set objCommonFile = objFSO.OpenTextFile(objFSO.BuildPath(strCWD, "Common.vbs"))
strCommon = objCommonFile.ReadAll
ExecuteGlobal strCommon
objCommonFile.Close
Set objCommonFile = Nothing
If Err.Number <> 0 Then
    WScript.Echo "Import script error: " & Err.Description
    WScript.Quit
End If

' Get macro args from file
Dim intMaxArgs, i, arrArgs()
intMaxArgs = 10
ReDim Preserve arrArgs(0)
arrArgs(0) = strMacro   ' app.run macro arg1 arg2 arg3
For i = 1 to intMaxArgs Step 1
    If objFSO.FileExists(strBasePath & "\arg" & i & ".txt") Then
        ReDim Preserve arrArgs(i)
        arrArgs(i) = GetParamFromFile(strBasePath & "\arg" & i & ".txt")
    End If
Next
' WScript.Echo "Number of args: " & UBound(arrArgs)

' Open workbook
Dim isExcelActive, isWorkbookActive
isExcelActive = False
isWorkbookActive = False
Set objExcel = Nothing
Set objWorkbook = Nothing
Call OpenWorkbook(objFSO, objExcel, objWorkbook, strBasePath, strFile, strPassword, isExcelActive, isWorkbookActive)

' Execute macro
Dim strOutput
Select case UBound(arrArgs)
    case 0
        strOutput = objExcel.Run(strMacro)
    case 1
        strOutput = objExcel.Run(strMacro, CStr(arrArgs(1)))
    case 2
        strOutput = objExcel.Run(strMacro, CStr(arrArgs(1)), CStr(arrArgs(2)))
    case 3
        strOutput = objExcel.Run(strMacro, CStr(arrArgs(1)), CStr(arrArgs(2)), CStr(arrArgs(3)))
    case 4
        strOutput = objExcel.Run(strMacro, CStr(arrArgs(1)), CStr(arrArgs(2)), CStr(arrArgs(3)), CStr(arrArgs(4)))
    case 5
        strOutput = objExcel.Run(strMacro, CStr(arrArgs(1)), CStr(arrArgs(2)), CStr(arrArgs(3)), CStr(arrArgs(4)), CStr(arrArgs(5)))
    case 6
        strOutput = objExcel.Run(strMacro, CStr(arrArgs(1)), CStr(arrArgs(2)), CStr(arrArgs(3)), CStr(arrArgs(4)), CStr(arrArgs(5)), CStr(arrArgs(6)))
    case 7
        strOutput = objExcel.Run(strMacro, CStr(arrArgs(1)), CStr(arrArgs(2)), CStr(arrArgs(3)), CStr(arrArgs(4)), CStr(arrArgs(5)), CStr(arrArgs(6)), CStr(arrArgs(7)))
    case 8
        strOutput = objExcel.Run(strMacro, CStr(arrArgs(1)), CStr(arrArgs(2)), CStr(arrArgs(3)), CStr(arrArgs(4)), CStr(arrArgs(5)), CStr(arrArgs(6)), CStr(arrArgs(7)), CStr(arrArgs(8)))
    case 9
        strOutput = objExcel.Run(strMacro, CStr(arrArgs(1)), CStr(arrArgs(2)), CStr(arrArgs(3)), CStr(arrArgs(4)), CStr(arrArgs(5)), CStr(arrArgs(6)), CStr(arrArgs(7)), CStr(arrArgs(8)), CStr(arrArgs(9)))
    case 10
        strOutput = objExcel.Run(strMacro, CStr(arrArgs(1)), CStr(arrArgs(2)), CStr(arrArgs(3)), CStr(arrArgs(4)), CStr(arrArgs(5)), CStr(arrArgs(6)), CStr(arrArgs(7)), CStr(arrArgs(8)), CStr(arrArgs(9)), CStr(arrArgs(10)))
    case Else
        WScript.Echo "Number of arguments exceeded " & intMaxArgs 
        Call CloseWorkbook(objFSO, objExcel, objWorkbook, strBasePath, isExcelActive, isWorkbookActive)
        WScript.Quit        
End Select

If Err.Number <> 0 Then
    Call WriteTextFile(strBasePath & "\error.txt", "Execute macro error: " & Err.Description)
    Call CloseWorkbook(objFSO, objExcel, objWorkbook, strBasePath, isExcelActive, isWorkbookActive)
    WScript.Quit
End If

Call WriteTextFile(strBasePath & "\output.txt", strOutput)

' Save excel and quit
objExcel.DisplayAlerts = False
objWorkbook.Save
If Err.Number <> 0 Then
    Call WriteTextFile(strBasePath & "\error.txt", "Save excel error: " & Err.Description)
    Err.Clear
End If

' Release system resources
Call CloseWorkbook(objFSO, objExcel, objWorkbook, strBasePath, isExcelActive, isWorkbookActive)

' Return success signal
WScript.Echo "OK"

On Error Goto 0
