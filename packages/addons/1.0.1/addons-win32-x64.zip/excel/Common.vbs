' Get param from file
Function GetParamFromFile(strPath)
    If objFSO.FileExists(strPath) Then
        Set objReadStream = CreateObject("ADODB.Stream")
        With objReadStream
            .CharSet = "UTF-8"
            .Open
            .LoadFromFile(strPath)
            GetParamFromFile = objReadStream.ReadText()
            .Close
        End With
        Set objReadStream = Nothing
    Else
        GetParamFromFile = ""
    End If
End Function

' Write text into file
Sub WriteTextFile(strPath, strContent)
    Set objWriteStream = CreateObject("ADODB.Stream")   ' UTF-8 BOM
    Set objWriteStream2 = CreateObject("ADODB.Stream")  ' Convert to UTF-8
    With objWriteStream
        .Type = 2   ' text
        .CharSet = "UTF-8"
        .Open
        .WriteText strContent
        .Position = 3   ' skip first char
    End With
    With objWriteStream2
        .Type = 1   ' binary
        .Open
        objWriteStream.CopyTo objWriteStream2
        .SaveToFile strPath, 2   ' overwrite
    End With
    objWriteStream.Close
    objWriteStream2.Close
End Sub

' Open workbook with password
Sub OpenWorkbook(objFSO, objExcel, objWorkbook, strBasePath, strFile, strPassword, isExcelActive, isWorkbookActive)
    On Error Resume Next
    Set objFile = objFSO.GetFile(strFile)
    If Err.Number <> 0 Then
        ' WScript.Echo "File not found: " & strFile
        Call WriteTextFile(strBasePath & "\error.txt", "File not found: " & Err.Description)
        WScript.Quit
    End If
    Dim strFileName
    strFileName = objFSO.GetFileName(objFile)
    Set objFile = Nothing

    Set objExcel = GetObject(, "Excel.Application")
    If Err.Number <> 0 Then
        ' WScript.Echo "Open excel application..." & Err.Description
        Set objExcel = CreateObject("Excel.Application")
        With objExcel
            .Visible = False
            .ScreenUpdating = False
        End With
        Err.Clear
    Else
        isExcelActive = True
    End If
    With objExcel
        .DisplayAlerts = False
        .AlertBeforeOverwriting = False
    End With
    ' WScript.Echo "Open excel...isActive:" & isExcelActive
    If Err.Number <> 0 Then
        Call WriteTextFile(strBasePath & "\error.txt", "Open excel error: " & Err.Description)
        WScript.Quit
    End If

    For Each obj In objExcel.Workbooks
        ' WScript.Echo "obj.Name: " & obj.Name & " strFileName: " & strFileName
        If obj.Name = strFileName Then
            isWorkbookActive = True
            Set objWorkbook = obj
            Exit For
        End If
    Next
    If Err.Number <> 0 Then
        Set objWorkbook = Nothing
        Err.Clear
    End If
    If objWorkbook Is Nothing Then
        ' WScript.Echo "Open excel workbook..."
        Set objWorkbook = objExcel.Workbooks.Open(strFile, , , , strPassword)
    End If
    If Err.Number <> 0 Then
        Call WriteTextFile(strBasePath & "\error.txt", "Open workbook error: " & Err.Description)
        If isExcelActive = False Then
            objExcel.Quit
        End If
        Set objExcel = Nothing
        Set objFSO = Nothing
        WScript.Quit
    End If
    ' WScript.Echo "Open workbook...isWorkbookActive:" & isWorkbookActive
End Sub

' Close workbook
Sub CloseWorkbook(objFSO, objExcel, objWorkbook, strBasePath, isExcelActive, isWorkbookActive)
    On Error Resume Next
    If isWorkbookActive = False Then
        objWorkbook.Close
    End If
    With objExcel
        .DisplayAlerts = True
        .AlertBeforeOverwriting = True
    End With
    If isExcelActive = False Then
        objExcel.Quit
    End If

    Set objSheet = Nothing
    Set objWorkbook = Nothing
    Set objExcel = Nothing
    Set objFSO = Nothing

    If Err.Number <> 0 Then
        Call WriteTextFile(strBasePath & "\error.txt", "Close workbook error: " & Err.Description)
        WScript.Quit
    End If
End Sub

' Open worksheet
Sub OpenWorksheet(objWorkbook, objSheet, strSheet)
    On Error Resume Next
    Set objSheet = objWorkbook.Sheets(strSheet)
    If Err.Number <> 0 Then
        If IsNumeric(strSheet) = True Then
            If CInt(strSheet) > 0 Then
                Err.Clear
                Set objSheet = objWorkbook.Sheets(CInt(strSheet))
            End If
        End If
    End If
End Sub
