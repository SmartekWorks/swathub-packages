' Get params from command line
Dim strPad, strBasePath, strFile, strPassword, strSheetNames
strPad = "ting.FileSys"
Set objFSO = CreateObject("Scrip" & strPad & "temObject")
Set objArgs = WScript.Arguments
strBasePath = objFSO.GetAbsolutePathName(objArgs(0))
strFile = objArgs(1)
strPassword = objArgs(2)
strSheetNames = ""

On Error Resume Next

' Include common scripts
Dim strCWD, strCommon
strCWD = Left(WScript.ScriptFullName, InStrRev(WScript.ScriptFullName, "\") - 1)
Set objCommonFile = objFSO.OpenTextFile(objFSO.BuildPath(strCWD, "Common.vbs"))
strCommon = objCommonFile.ReadAll
ExecuteGlobal strCommon
objCommonFile.Close
Set objCommonFile = Nothing
If Err.Number <> 0 Then
    WScript.Echo "Import script error: " & Err.Description
    WScript.Quit
End If

' Open workbook
Dim isExcelActive, isWorkbookActive
isExcelActive = False
isWorkbookActive = False
Set objExcel = Nothing
Set objWorkbook = Nothing
Call OpenWorkbook(objFSO, objExcel, objWorkbook, strBasePath, strFile, strPassword, isExcelActive, isWorkbookActive)

' Get sheet names
For Each objSheet In objWorkbook.Sheets
    strSheetNames = strSheetNames & objSheet.Name & vbNewLine
Next
Call WriteTextFile(strBasePath & "\output.txt", strSheetNames)
If Err.Number <> 0 Then
    Call WriteTextFile(strBasePath & "\error.txt", "Get sheet names error: " & Err.Description)
    Err.Clear
End If

' Release system resources
Call CloseWorkbook(objFSO, objExcel, objWorkbook, strBasePath, isExcelActive, isWorkbookActive)

' Return success signal
WScript.Echo "OK"

On Error Goto 0
