' Get params from command line
Dim strPad, strBasePath, strFile, strPassword
strPad = "ting.FileSys"
Set objFSO = CreateObject("Scrip" & strPad & "temObject")
Set objArgs = WScript.Arguments
strBasePath = objFSO.GetAbsolutePathName(objArgs(0))
strFile = objArgs(1)
strOldPassword = objArgs(2)
strNewPassword = objArgs(3)

On Error Resume Next

' Include common scripts
Dim strCWD, strCommon
strCWD = Left(WScript.ScriptFullName, InStrRev(WScript.ScriptFullName, "\") - 1)
Set objCommonFile = objFSO.OpenTextFile(objFSO.BuildPath(strCWD, "Common.vbs"))
strCommon = objCommonFile.ReadAll
ExecuteGlobal strCommon
objCommonFile.Close
Set objCommonFile = Nothing
If Err.Number <> 0 Then
    WScript.Echo "Import script error: " & Err.Description
    WScript.Quit
End If

' Open workbook with password
Dim isExcelActive, isWorkbookActive, isVisible
isExcelActive = False
isWorkbookActive = False
Set objExcel = Nothing
Set objWorkbook = Nothing
Call OpenWorkbook(objFSO, objExcel, objWorkbook, strBasePath, strFile, strOldPassword, isExcelActive, isWorkbookActive)

' Save as new file with password
objExcel.DisplayAlerts = False
Call objWorkbook.SaveAs(strFile, , strNewPassword)
If Err.Number <> 0 Then
    WScript.Echo "Encrypt file error: " & Err.Description
    Call WriteTextFile(strBasePath & "\error.txt", "Encrypt file error: " & Err.Description)
    Err.Clear
End If

' Close excel and workbook
Call CloseWorkbook(objFSO, objExcel, objWorkbook, strBasePath, isExcelActive, isWorkbookActive)

' Return success signal
WScript.Echo "OK"

On Error Goto 0