' Get params from command line
Dim strPad, strBasePath, strFile, strSheet, strCell, strPassword, strValue
strPad = "ting.FileSys"
Set objFSO = CreateObject("Scrip" & strPad & "temObject")
Set objArgs = WScript.Arguments
strBasePath = objFSO.GetAbsolutePathName(objArgs(0))
strFile = objArgs(1)
strSheet = objArgs(2)
strCell = objArgs(3)
strPassword = objArgs(4)

On Error Resume Next

' Include common scripts
Dim strCWD, strCommon
strCWD = Left(WScript.ScriptFullName, InStrRev(WScript.ScriptFullName, "\") - 1)
Set objCommonFile = objFSO.OpenTextFile(objFSO.BuildPath(strCWD, "Common.vbs"))
strCommon = objCommonFile.ReadAll
ExecuteGlobal strCommon
objCommonFile.Close
Set objCommonFile = Nothing
If Err.Number <> 0 Then
    WScript.Echo "Import script error: " & Err.Description
    WScript.Quit
End If

' Open workbook
Dim isExcelActive, isWorkbookActive
isExcelActive = False
isWorkbookActive = False
Set objExcel = Nothing
Set objWorkbook = Nothing
Call OpenWorkbook(objFSO, objExcel, objWorkbook, strBasePath, strFile, strPassword, isExcelActive, isWorkbookActive)

' Open worksheet
Set objSheet = Nothing
Call OpenWorksheet(objWorkbook, objSheet, strSheet)
If Err.Number <> 0 Then
    Call WriteTextFile(strBasePath & "\error.txt", "Sheet not found: " & Err.Description)
    Call CloseWorkbook(objFSO, objExcel, objWorkbook, strBasePath, isExcelActive, isWorkbookActive)
    WScript.Quit
End If

' Read cell formula
strValue = objSheet.Range(strCell).Formula
Call WriteTextFile(strBasePath & "\output.txt", strValue)
If Err.Number <> 0 Then
    Call WriteTextFile(strBasePath & "\output.txt", "#VALUE!")
    Err.Clear
End If

' Release system resources
Call CloseWorkbook(objFSO, objExcel, objWorkbook, strBasePath, isExcelActive, isWorkbookActive)

' Return success signal
WScript.Echo "OK"

On Error Goto 0
