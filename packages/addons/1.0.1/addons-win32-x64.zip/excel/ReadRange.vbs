' Get params from command line
On Error Resume Next
Dim strPad, strBasePath, strFile, strSheet, strRange, strPassword
strPad = "ting.FileSys"
Set objFSO = CreateObject("Scrip" & strPad & "temObject")
If Err.Number <> 0 Then
    WScript.Echo "Read range error (Initialize): " & Err.Description
    WScript.Quit 0
End If
Set objArgs = WScript.Arguments
If objArgs.Count < 4 Then
    WScript.Echo "Read range error (Arguments): Expected work path, workbook, sheet and range"
    WScript.Quit 0
End If
strBasePath = objFSO.GetAbsolutePathName(objArgs(0))
strFile = objArgs(1)
strSheet = objArgs(2)
strRange = objArgs(3)
strPassword = ""
If objArgs.Count > 4 Then strPassword = objArgs(4)

' Include common scripts
Dim strCWD, strCommon
strCWD = Left(WScript.ScriptFullName, InStrRev(WScript.ScriptFullName, "\") - 1)
Set objCommonFile = objFSO.OpenTextFile(objFSO.BuildPath(strCWD, "Common.vbs"))
strCommon = objCommonFile.ReadAll
ExecuteGlobal strCommon
objCommonFile.Close
Set objCommonFile = Nothing
If Err.Number <> 0 Then
    WScript.Echo "Import script error: " & Err.Description
    WScript.Quit
End If

' Open workbook
Dim isExcelActive, isWorkbookActive, savedAlerts, savedOverwriteAlerts, alertsCaptured
isExcelActive = False
isWorkbookActive = False
Set objExcel = Nothing
Set objWorkbook = Nothing
Set objTmpWorkbook = Nothing
Set objTarget = Nothing
alertsCaptured = False
Call OpenReadWorkbook()

' Open worksheet
Set objSheet = Nothing
Call OpenWorksheet(objWorkbook, objSheet, strSheet)
If Err.Number <> 0 Then
    Call FinishReadRange("Sheet not found: " & Err.Description)
End If

' Open range
If InStr(strRange, ":") = 0 Then
    strRange = "A1:" & objSheet.Range("A1").SpecialCells(11).Address ' xlCellTypeLastCell
    If Err.Number <> 0 Then
        Err.Clear
        Set usedRange = objSheet.UsedRange
        strRange = "A1:" & objSheet.Cells(usedRange.Row + usedRange.Rows.Count - 1, usedRange.Column + usedRange.Columns.Count - 1).Address
        If Err.Number <> 0 Then Call FailReadRange("Get automatic range", Err.Number, Err.Description)
        Set usedRange = Nothing
    End If
End If
If InStr(strRange, ":") > 0 Then
    Set objRange = objSheet.Range(strRange)
End If
If Err.Number <> 0 Then
    Call FinishReadRange("Invalid range: " & Err.Description)
End If

' Transfer values and their display formats without using the clipboard.
' Keep Excel's CSV serializer (including Local:=True) so quoting, delimiters
' and formatted dates/numbers follow the same rules as the original reader.
Dim strDataFile, strDataContent
strDataFile = strBasePath & "\data.csv"
Err.Clear
Set objTmpWorkbook = objExcel.Workbooks.Add(1)
If Err.Number <> 0 Then Call FailReadRange("Create temporary workbook", Err.Number, Err.Description)
Call PopulateExportRange()
Err.Clear
objTmpWorkbook.SaveAs strDataFile, 62, , , , False, , , , , , True ' xlCSVUTF8
If Err.Number <> 0 Then
    ' Only a failed CSV SaveAs enters the legacy format fallback. A failure
    ' to read/transfer cells must never be mistaken for missing UTF-8 support.
    Err.Clear
    objTmpWorkbook.SaveAs strDataFile, 6, , , , False, , , , , , True ' xlCSV
    If Err.Number <> 0 Then Call FailReadRange("Save CSV", Err.Number, Err.Description)
    objTmpWorkbook.Close False
    If Err.Number <> 0 Then Call FailReadRange("Close temporary workbook", Err.Number, Err.Description)
    Set objTmpWorkbook = Nothing

    ' Convert csv to utf-8
    Set objWriteStream = CreateObject("ADODB.Stream")
    Set objDataFile = objFSO.OpenTextFile(strDataFile, 1) ' reading
    strDataContent = objDataFile.ReadAll
    objDataFile.Close
    ' WScript.Echo "CSV data content: " & strDataContent
    With objWriteStream
        .Type = 2 ' text
        .CharSet = "UTF-8"
        .Open
        .WriteText strDataContent
        .SaveToFile strDataFile, 2 ' overwrite
        .Close
    End With
    Set objDataFile = Nothing
    Set objWriteStream = Nothing
    If Err.Number <> 0 Then Call FailReadRange("Convert CSV to UTF-8", Err.Number, Err.Description)
End If

Call FinishReadRange("")

On Error Goto 0

Sub PopulateExportRange()
    On Error Resume Next
    Dim values, r, c, numberFormat, exportSource, exportRows, exportColumns, readFailure
    Err.Clear
    ' Do not materialize unused trailing rows/columns. PasteAll leaves a
    ' completely unused source range empty; assigning an Empty array would
    ' otherwise create extra blank CSV records.
    Call GetExportSize(exportRows, exportColumns)
    If exportRows = 0 Or exportColumns = 0 Then Exit Sub
    Set exportSource = objRange.Cells(1, 1).Resize(exportRows, exportColumns)
    If Err.Number <> 0 Then Call FailReadRange("Get source range", Err.Number, Err.Description)
    If Not TryReadRangeValues(exportSource, values, readFailure) Then Call FinishReadRange(readFailure)
    Set objTarget = objTmpWorkbook.Sheets(1).Range("A1").Resize(exportRows, exportColumns)
    If Err.Number <> 0 Then Call FailReadRange("Get export range", Err.Number, Err.Description)

    ' Preserve strings such as 00123, 20-digit identifiers and =literal.
    ' Text formatting preserves normal strings; escape a literal leading
    ' apostrophe so Excel does not consume it as an input marker.
    If IsArray(values) Then
        For r = LBound(values, 1) To UBound(values, 1)
            For c = LBound(values, 2) To UBound(values, 2)
                If VarType(values(r, c)) = vbString Then
                    If Left(values(r, c), 1) = "'" Then values(r, c) = "'" & values(r, c)
                End If
            Next
        Next
    ElseIf VarType(values) = vbString Then
        If Left(values, 1) = "'" Then values = "'" & values
    End If
    objTarget.NumberFormat = "@"
    objTarget.Value2 = values
    If Err.Number <> 0 Then Call FailReadRange("Transfer values", Err.Number, Err.Description)

    ' Value2 keeps full numeric precision; NumberFormat supplies the visible
    ' date/time, percentage, currency and custom formats during CSV export.
    ' Keep the temporary workbook's default date system, as PasteAll did.
    numberFormat = exportSource.NumberFormat
    ' Some protection providers reject bulk access but allow individual cells.
    If Err.Number <> 0 Then
        Err.Clear
        numberFormat = Null
    End If
    If IsNull(numberFormat) Then
        For r = 1 To exportRows
            For c = 1 To exportColumns
                numberFormat = exportSource.Cells(r, c).NumberFormat
                If Err.Number <> 0 Then Call FailReadRange("Read number format " & exportSource.Cells(r, c).Address, Err.Number, Err.Description)
                objTarget.Cells(r, c).NumberFormat = numberFormat
                If Err.Number <> 0 Then Call FailReadRange("Apply number format", Err.Number, Err.Description)
            Next
        Next
    Else
        objTarget.NumberFormat = numberFormat
    End If
    If Err.Number <> 0 Then Call FailReadRange("Apply number format", Err.Number, Err.Description)
End Sub

Function TryReadRangeValues(source, ByRef values, ByRef failure)
    On Error Resume Next
    Dim rows, columns, recovered()
    failure = ""
    TryReadRangeValues = False
    Err.Clear
    values = source.Value2
    If Err.Number = 0 Then
        TryReadRangeValues = True
        Exit Function
    End If
    Err.Clear
    rows = source.Rows.Count
    columns = source.Columns.Count
    ReDim recovered(rows - 1, columns - 1)
    If Err.Number <> 0 Then
        failure = "Read range error (Allocate fallback, " & Err.Number & "): " & Err.Description
        Exit Function
    End If
    ' Split only after the fast bulk call fails. Do not replay that root call.
    If Not FillReadBlock(source, 1, 1, rows, columns, recovered, failure, False) Then Exit Function
    values = recovered
    TryReadRangeValues = True
End Function

Function FillReadBlock(source, firstRow, firstColumn, rows, columns, ByRef result, ByRef failure, tryBulk)
    On Error Resume Next
    Dim block, values, r, c, split, errorNumber, errorDescription, address
    FillReadBlock = False
    Err.Clear
    Set block = source.Cells(firstRow, firstColumn).Resize(rows, columns)
    If Err.Number <> 0 Then
        failure = "Read range error (Get fallback block, " & Err.Number & "): " & Err.Description
        Exit Function
    End If
    If tryBulk Or (rows = 1 And columns = 1) Then
        values = block.Value2
        errorNumber = Err.Number
        errorDescription = Err.Description
        Err.Clear
        If errorNumber = 0 Then
            If rows = 1 And columns = 1 Then
                result(firstRow - 1, firstColumn - 1) = values
            Else
                For r = 0 To rows - 1
                    For c = 0 To columns - 1
                        result(firstRow + r - 1, firstColumn + c - 1) = values(LBound(values, 1) + r, LBound(values, 2) + c)
                    Next
                Next
            End If
            If Err.Number <> 0 Then
                failure = "Read range error (Assemble fallback, " & Err.Number & "): " & Err.Description
                Exit Function
            End If
            FillReadBlock = True
            Exit Function
        End If
        If rows = 1 And columns = 1 Then
            address = "row " & firstRow & ", column " & firstColumn
            address = block.Address
            Err.Clear
            failure = "Read range error (Read values " & address & ", " & errorNumber & "): " & errorDescription
            Exit Function
        End If
    End If
    ' Bisect the longer dimension; recursion depth is logarithmic, not per row.
    If rows >= columns And rows > 1 Then
        split = rows \ 2
        If Not FillReadBlock(source, firstRow, firstColumn, split, columns, result, failure, True) Then Exit Function
        If Not FillReadBlock(source, firstRow + split, firstColumn, rows - split, columns, result, failure, True) Then Exit Function
    Else
        split = columns \ 2
        If Not FillReadBlock(source, firstRow, firstColumn, rows, split, result, failure, True) Then Exit Function
        If Not FillReadBlock(source, firstRow, firstColumn + split, rows, columns - split, result, failure, True) Then Exit Function
    End If
    FillReadBlock = True
End Function

Sub OpenReadWorkbook()
    On Error Resume Next
    Dim candidate, sameName, targetPath
    Err.Clear
    targetPath = objFSO.GetAbsolutePathName(strFile)
    If Err.Number <> 0 Then Call FailReadRange("Resolve workbook path", Err.Number, Err.Description)
    Set objExcel = GetObject(, "Excel.Application")
    If Err.Number = 0 Then
        isExcelActive = True
        sameName = False
        For Each candidate In objExcel.Workbooks
            If StrComp(candidate.FullName, targetPath, vbTextCompare) = 0 Then
                Set objWorkbook = candidate
                isWorkbookActive = True
                Exit For
            End If
            If StrComp(candidate.Name, objFSO.GetFileName(targetPath), vbTextCompare) = 0 Then sameName = True
        Next
        If Err.Number <> 0 Then Call FailReadRange("Inspect open workbooks", Err.Number, Err.Description)
        If sameName And Not isWorkbookActive Then
            Set objExcel = Nothing
            isExcelActive = False
        End If
    Else
        Err.Clear
    End If
    If Not isExcelActive Then
        Set objExcel = CreateObject("Excel.Application")
        If Err.Number <> 0 Then Call FailReadRange("Open Excel", Err.Number, Err.Description)
        objExcel.Visible = False
        objExcel.ScreenUpdating = False
    End If
    savedAlerts = objExcel.DisplayAlerts
    savedOverwriteAlerts = objExcel.AlertBeforeOverwriting
    If Err.Number <> 0 Then Call FailReadRange("Read Excel state", Err.Number, Err.Description)
    alertsCaptured = True
    objExcel.DisplayAlerts = False
    objExcel.AlertBeforeOverwriting = False
    If Err.Number <> 0 Then Call FailReadRange("Configure Excel", Err.Number, Err.Description)
    If Not isWorkbookActive Then
        ' Read-only also prevents Excel from updating legacy XLS metadata
        ' simply by opening and closing the source through COM.
        Set objWorkbook = objExcel.Workbooks.Open(targetPath, , True, , strPassword)
        If Err.Number <> 0 Then Call FailReadRange("Open workbook", Err.Number, Err.Description)
        If objWorkbook Is Nothing Then Call FinishReadRange("Read range error (Open workbook): Excel returned no workbook")
    End If
End Sub

Sub GetExportSize(ByRef rows, ByRef columns)
    On Error Resume Next
    Dim layout, tags, tag, pattern, attributes, attribute, row, column, bottom, right
    Dim index, mergeDown, mergeAcross
    rows = 0
    columns = 0
    row = 0
    column = 0
    Err.Clear
    ' Native range XML lists populated/styled cells sparsely, including
    ' blank cells with formatting. Inspect only tag attributes for bounds;
    ' never parse/rewrite Data text (CR/control characters must stay intact).
    layout = objRange.Value(11) ' xlRangeValueXMLSpreadsheet
    If Err.Number <> 0 Then
        ' XML is only a legacy trailing-blank optimization, not read permission.
        ' The selected range is already bounded (explicit range or auto range).
        ' Preserve its shape when XML export is unavailable; never return empty.
        Err.Clear
        rows = objRange.Rows.Count
        columns = objRange.Columns.Count
        If Err.Number <> 0 Then Call FailReadRange("Read export dimensions", Err.Number, Err.Description)
        Exit Sub
    End If
    Set pattern = New RegExp
    pattern.Global = True
    pattern.Pattern = "<(Row|Cell)\b[^>]*>"
    Set tags = pattern.Execute(layout)
    Set attributes = New RegExp
    attributes.Global = True
    attributes.Pattern = "ss:(Index|MergeDown|MergeAcross)=""([0-9]+)"""
    For Each tag In tags
        index = 0
        mergeDown = 0
        mergeAcross = 0
        For Each attribute In attributes.Execute(tag.Value)
            Select Case attribute.SubMatches(0)
                Case "Index": index = CLng(attribute.SubMatches(1))
                Case "MergeDown": mergeDown = CLng(attribute.SubMatches(1))
                Case "MergeAcross": mergeAcross = CLng(attribute.SubMatches(1))
            End Select
        Next
        If tag.SubMatches(0) = "Row" Then
            row = row + 1
            If index > 0 Then row = index
            column = 0
        Else
            column = column + 1
            If index > 0 Then column = index
            bottom = row + mergeDown
            right = column + mergeAcross
            If bottom > rows Then rows = bottom
            If right > columns Then columns = right
            column = right
        End If
    Next
    If rows > objRange.Rows.Count Then rows = objRange.Rows.Count
    If columns > objRange.Columns.Count Then columns = objRange.Columns.Count
    If Err.Number <> 0 Then Call FailReadRange("Read export dimensions", Err.Number, Err.Description)
End Sub

Sub FailReadRange(stage, errorNumber, errorDescription)
    Call FinishReadRange("Read range error (" & stage & ", " & errorNumber & "): " & errorDescription)
End Sub

Sub FinishReadRange(failure)
    On Error Resume Next
    Err.Clear
    Set objTarget = Nothing
    If Not objTmpWorkbook Is Nothing Then objTmpWorkbook.Close False
    If Err.Number <> 0 And failure = "" Then failure = "Read range error (Close temporary workbook): " & Err.Description
    Set objTmpWorkbook = Nothing
    Set objRange = Nothing
    Set objSheet = Nothing
    Err.Clear
    If Not objWorkbook Is Nothing Then
        If Not isWorkbookActive Then objWorkbook.Close False
    End If
    If Err.Number <> 0 And failure = "" Then failure = "Read range error (Close workbook): " & Err.Description
    Set objWorkbook = Nothing
    Err.Clear
    If Not objExcel Is Nothing Then
        If alertsCaptured Then
            objExcel.DisplayAlerts = savedAlerts
            objExcel.AlertBeforeOverwriting = savedOverwriteAlerts
        End If
        If Not isExcelActive Then objExcel.Quit
    End If
    If Err.Number <> 0 And failure = "" Then failure = "Read range error (Close Excel): " & Err.Description
    Set objExcel = Nothing
    If failure <> "" Then
        Call WriteTextFile(strBasePath & "\error.txt", failure)
        WScript.Echo failure
    Else
        WScript.Echo "OK"
    End If
    WScript.Quit 0
End Sub
