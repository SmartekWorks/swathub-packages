' Get params from command line
Dim strPad, strBasePath, strSrcFile, strSrcSheet, strSrcPassword, strDstFile, strDstSheet, strDstPassword
strPad = "ting.FileSys"
Set objFSO = CreateObject("Scrip" & strPad & "temObject")
Set objArgs = WScript.Arguments
strBasePath = objFSO.GetAbsolutePathName(objArgs(0))
strSrcFile = objArgs(1)
strSrcSheet = objArgs(2)
strSrcPassword = objArgs(3)
strDstFile = objArgs(4)
strDstSheet = objArgs(5)
strDstPassword = objArgs(6)

On Error Resume Next

' Include common scripts
Dim strCWD, strCommon
strCWD = Left(WScript.ScriptFullName, InStrRev(WScript.ScriptFullName, "\") - 1)
Set objCommonFile = objFSO.OpenTextFile(objFSO.BuildPath(strCWD, "Common.vbs"))
strCommon = objCommonFile.ReadAll
ExecuteGlobal strCommon
objCommonFile.Close
Set objCommonFile = Nothing
If Err.Number <> 0 Then
    WScript.Echo "Import script error: " & Err.Description
    WScript.Quit
End If

' Open source workbook
Dim strSrcFileName, strDstFileName, isExcelActive, isSrcWorkbookActive, isDstWorkbookActive
isExcelActive = False
isSrcWorkbookActive = False
isDstWorkbookActive = False

Set objFile = objFSO.GetFile(strSrcFile)
If Err.Number <> 0 Then
    WScript.Echo "Source file not found: " & strSrcFile
    WScript.Quit
End If
strSrcFileName = objFSO.GetFileName(objFile)

Set objFile = objFSO.GetFile(strDstFile)
If Err.Number <> 0 Then
    WScript.Echo "Source file not found: " & strDstFile
    WScript.Quit
End If
strDstFileName = objFSO.GetFileName(objFile)
' WScript.Echo "strFileName: " & strFileName

Set objExcel = GetObject(, "Excel.Application")
If Err.Number <> 0 Then
    ' WScript.Echo "Open excel application..." & Err.Description
    Set objExcel = CreateObject("Excel.Application")
    objExcel.visible = False
    Err.Clear
Else
    isExcelActive = True
End If

' Get source sheet
Set objSrcWorkbook = Nothing
For Each obj In objExcel.Workbooks
    ' WScript.Echo "obj.Name: " & obj.Name & " strFileName: " & strFileName
    If obj.Name = strSrcFileName Then
        isSrcWorkbookActive = True
        Set objSrcWorkbook = obj
        Exit For
    End If
Next
If objSrcWorkbook Is Nothing Then
    ' WScript.Echo "Open excel workbook..."
    Set objSrcWorkbook = objExcel.Workbooks.Open(strSrcFile, , , , strSrcPassword)
End If
If Err.Number <> 0 Then
    Call WriteTextFile(strBasePath & "\error.txt", "Open source workbook error: " & Err.Description)
    If isExcelActive = False Then
        objExcel.Quit
    End If
    Set objExcel = Nothing
    Set objFSO = Nothing
    WScript.Quit
End If

Set objSrcSheet = Nothing
Call OpenWorksheet(objSrcWorkbook, objSrcSheet, strSrcSheet)
If Err.Number <> 0 Then
    Call WriteTextFile(strBasePath & "\error.txt", "Source sheet not found: " & Err.Description)
    If isSrcWorkbookActive = False Then
        objSrcWorkbook.Close
    End If
    If isExcelActive = False Then
        objExcel.Quit
    End If
    Set objSrcWorkbook = Nothing
    Set objExcel = Nothing
    Set objFSO = Nothing
    WScript.Quit
End If

' Copy to destination sheet
Set objDstWorkbook = Nothing
For Each obj In objExcel.Workbooks
    ' WScript.Echo "obj.Name: " & obj.Name & " strFileName: " & strFileName
    If obj.Name = strDstFileName Then
        isDstWorkbookActive = True
        Set objDstWorkbook = obj
        Exit For
    End If
Next
If objDstWorkbook Is Nothing Then
    ' WScript.Echo "Open excel workbook..."
    Set objDstWorkbook = objExcel.Workbooks.Open(strDstFile, , , , strDstPassword)
End If
If Err.Number <> 0 Then
    Call WriteTextFile(strBasePath & "\error.txt", "Open destination workbook error: " & Err.Description)
    If isSrcWorkbookActive = False Then
        objSrcWorkbook.Close
    End If
    If isExcelActive = False Then
        objExcel.Quit
    End If
    Set objSrcSheet = Nothing
    Set objSrcWorkbook = Nothing
    set objDstWorkbook = Nothing
    Set objExcel = Nothing
    Set objFSO = Nothing
    WScript.Quit
End If

Set objDstSheet = Nothing
Call OpenWorksheet(objDstWorkbook, objDstSheet, strDstSheet)
If Err.Number = 0 Then
    Call WriteTextFile(strBasePath & "\error.txt", "Destination sheet exists: " & strDstSheet)
    If isSrcWorkbookActive = False Then
        objSrcWorkbook.Close
    End If
    If isDstWorkbookActive = False Then
        objDstWorkbook.Close
    End If
    If isExcelActive = False Then
        objExcel.Quit
    End If
    Set objSrcSheet = Nothing
    Set objSrcWorkbook = Nothing
    set objDstWorkbook = Nothing
    Set objExcel = Nothing
    Set objFSO = Nothing
    WScript.Quit
Else
    Err.Clear
End If

Call objSrcSheet.Copy(, objDstWorkbook.Sheets(objDstWorkbook.Sheets.Count))
objDstWorkbook.Sheets(objDstWorkbook.Sheets.Count).Name = strDstSheet

objExcel.DisplayAlerts = False
objDstWorkbook.Save
If isSrcWorkbookActive = False Then
    objSrcWorkbook.Close
End If
If isDstWorkbookActive = False Then
    objDstWorkbook.Close
End If
If isExcelActive = False Then
    objExcel.Quit
Else
    objExcel.DisplayAlerts = True
End If
If Err.Number <> 0 Then
    WScript.Echo "Sheet copy error: " & Err.Description
    Call WriteTextFile(strBasePath & "\error.txt", "Sheet copy error: " & Err.Description)
    Err.Clear
End If

' Release system resources
Set objSrcSheet = Nothing
Set objDstSheet = Nothing
Set objSrcWorkbook = Nothing
Set objDstWorkbook = Nothing
Set objExcel = Nothing
Set objFSO = Nothing

' Return success signal
WScript.Echo "OK"

On Error Goto 0
