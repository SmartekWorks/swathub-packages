Set objArgs = WScript.Arguments
Dim objStream, msgContent, msgTitle
Set objStream = CreateObject("ADODB.Stream")
objStream.CharSet = "utf-8"
objStream.Open
objStream.LoadFromFile(objArgs(0) & "\content.txt")
msgContent = objStream.ReadText()
objStream.Close

objStream.Open
objStream.LoadFromFile(objArgs(0) & "\title.txt")
msgTitle = objStream.ReadText()
objStream.Close

If msgTitle = "" Then
  msgTitle = "Message Box"
End If
MsgBox msgContent, , msgTitle